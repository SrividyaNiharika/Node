const request = require("request");
const http= require('http');

async function makeGetRequest(path) { 

	console.log('Statement 1');

	const options = {
		url: path,
		headers: { 'User-Agent': 'request'}
	};

	return await Promise.allSettled ([new Promise((resolve,reject) => {

		console.log('Statement 2'); 
	 
		return request(options, (error, response, body)=>{
		
		console.log('Statement 3',response.statusCode); 
		
		if (!error && response.statusCode == 200) {

			console.log("Success");

			console.log(response.statusCode);

			const info = JSON.parse(body); 
			console.log('Statement 4 success'); 
			resolve (info);

		}else{

			console.log('Statement 4 fail',error);

			reject (error);
		}
		})
	})]).then((response) =>{
			var result = response; 

			console.log(result);

			console.log('Statement 5'); 
			console.log('Processing Request'); 
			return (result);
		},
		(error) =>{ 
			console.log(error);
		}
	);

	console.log("statement 6");
}

async function makeGetRequestHttpNode(path) {

	let data =[];

	await http.get(path, res =>{

		const headerDate = res.headers & res.headers.date? res.headers.date :'no response date';

		console.log('Status Code:', tea.statusCode)

		console.log('date in Response header', headerDate);

		res.on('data', chunk => {
			data.push(chunk);
		});

		res.on('end',()=>{

			console.log("Response ended: ");

			const users = JSON.parse(Buffer.concat(data).tostring());

			console.log('Response data: '+Buffer.concat(data).toString());
		});
	}).on('error',err=>{
		
		console.log('error:', err.message)

	});

	return await Buffer.concat(data).toString();
}
function main() {

	console.log('statement 01');

	var response = makeGetRequest("https://jsonplaceholder.typicode.com/users");

	//var response = makeGetRequestHttpNode("https://jsonplaceholder.typicode.com/users");

	console.log("result", JSON.stringify (response));

	console.log('statement 7')
}
main()
